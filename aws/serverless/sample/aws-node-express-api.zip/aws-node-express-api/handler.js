const serverless = require("serverless-http");
const express = require("express");
const app = express();

const obj = {
  name: 'joe',
  age: 35,
  person1: {
    name: 'Tony',
    age: 50,
    person2: {
      name: 'Albert',
      age: 21,
      person3: {
        name: 'Peter',
        age: 23
      }
    }
  }
}


app.get("/", (req, res, next) => {
  console.log("A log message under the root path.");
  console.log(obj);
  return res.status(200).json({
    message: "Hello from root!",
  });
});

app.get("/hello", (req, res, next) => {
  console.log("A log message under the hello path.");
  //console.warn('this is a message', {'some-extra-data': 'hello'});
  return res.status(200).json({
    message: "Hello from the hello path!",
  });
});

app.get("/customer", (req, res, next) => {
  console.log("A log message under the customer path.");
  //console.warn('this is a message', {'some-extra-data': 'hello'});
  return res.status(200).json({
    message: "Hello from the customer path!",
  });
});

app.use((req, res, next) => {
  return res.status(404).json({
    error: "Not Found",
  });
});

module.exports.handler = serverless(app);
