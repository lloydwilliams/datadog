#!/bin/sh
export DD_ENV=dev
export DD_SERVICE=bba-opo-server
export DD_VERSION=1.1.6
export DD_TAGS=owner:lloyd,cloud_provider:aws

#https://docs.datadoghq.com/tracing/runtime_metrics/nodejs/
#private beta
export DD_RUNTIME_METRICS_ENABLED=true
#DEFAULT DASHBOARD
#https://app.datadoghq.com/dash/integration/30269/node-runtime-metrics?_gl=1%2A1oxqen7%2A_gcl_aw%2AR0NMLjE2MzQzMjk0MDIuQ2p3S0NBand6YVNMQmhCSkVpd0FKU1Jva2kxSVpZQ0M1UmdSTFBPZnNYUmpqUG5MZHhxckVELVBDMDlrVUhheEV6NXB0bmpmRGRYcUhCb0NKOW9RQXZEX0J3RQ..%2A_ga%2AMTA2OTY2MDc2OS4xNjExNjE5MTMw%2A_ga_KN80RDFSQK%2AMTYzNDQxODk0NC4zMTAuMS4xNjM0NDIwNjIwLjA.&from_ts=1634417113682&to_ts=1634420713682&live=true


export DD_LOGS_INJECTION=true

pm2 start ./index.js --attach --time --output /u01/nodejs/hapi-sample/myproject/logs/output.log --error /u01/nodejs/hapi-sample/myproject/logs/error.log 
