@javax.xml.bind.annotation.XmlSchema(namespace = "http://hello_world.webservices.examples/")
package examples.webservices.hello_world.client;
