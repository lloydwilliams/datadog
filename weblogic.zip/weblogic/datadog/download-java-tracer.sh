#!/bin/sh
#wget -O dd-java-agent.jar https://dtdg.co/latest-java-tracer
wget --no-check-certificate -O dd-java-agent.jar https://dtdg.co/latest-java-tracer