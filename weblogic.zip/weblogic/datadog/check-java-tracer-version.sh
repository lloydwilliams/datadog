#!/bin/sh
java -jar dd-java-agent.jar
