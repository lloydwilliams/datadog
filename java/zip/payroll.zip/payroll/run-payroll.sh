#!/bin/sh

# java -jar target/payroll-3.0.1.jar

# java -Xms256m -Xmx256m -Duser.timezone=UTC -jar target/payroll-3.0.1.jar

export DD_TAGS="git.commit.sha:96fd411ba2fcb4b1969b4e7f6fa5a0798580f90f git.repository_url:github.com/lloydwilliams/datadog/tree/main/kubernetes/payroll/eclipse-workspace/payroll"

java -javaagent:/Users/lloyd.williams/u01/datadog/dd-java-agent.jar \
 -Ddd.trace.methods=com.example.payroll.EmployeeController[*] \
 -Ddd.logs.injection=true -Ddd.appsec.enabled=true \
 -Ddd.service=payroll -Ddd.source=java -Ddd.env=dev -Ddd.version=3.0.1 -Duser.timezone=UTC -jar target/payroll-3.0.1.jar